package me.planetguy.remaininmotion ;

public class BlockRecordSet extends java . util . TreeSet < BlockRecord >
{
}
