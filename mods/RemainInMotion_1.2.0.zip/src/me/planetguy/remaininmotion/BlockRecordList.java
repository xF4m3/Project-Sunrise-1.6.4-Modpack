package me.planetguy.remaininmotion ;

public class BlockRecordList extends java . util . ArrayList < BlockRecord >
{
}
