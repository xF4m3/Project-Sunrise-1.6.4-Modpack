Hey there everybody! Welcome to the Tropicraft zip! Inside you see the following:

- mods folder

Inside this folder there are zips with all the mods required for Tropicraft to work.

DO NOT OPEN/EXTRACT THESE, LEAVE THEM BE!!!!

FOR BOTH CLIENT AND SERVER:
- Copy the 'mods' folder into your main server root path or your .minecraft folder on your computer. 
  As long as the zips end up directly inside the mods folder on the server or client, you have done it right!

